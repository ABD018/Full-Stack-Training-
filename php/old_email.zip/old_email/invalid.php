<?php
echo "Invalid login or registration attempt.";
?>
