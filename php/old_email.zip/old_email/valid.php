<?php
echo "Successful login or registration!";
?>
